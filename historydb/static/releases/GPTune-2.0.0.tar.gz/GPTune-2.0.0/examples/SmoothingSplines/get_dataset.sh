wget https://archive.ics.uci.edu/ml/machine-learning-databases/00235/household_power_consumption.zip
mkdir household
mv household_power_consumption.zip household/
cd household/
unzip household_power_consumption.zip
